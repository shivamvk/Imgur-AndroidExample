package io.shivamvk.imgur_androidexample;

public class Constants{

    //Imgur Api client id and secret
    public static final String client_id = "ba496ffbb44166d";
    public static final String client_secret = "7bdc72a3402e40b2cb9d0c17f7e3020b7122368b";
}
